export interface Cut {
  id: string;
  cut_number: number;
  date: string;
  establishment_id: string;
  establishment?: {
    name: string;
  };
  code: string;
  income_code?: {
    description: string;
  };
  amount: number;
  month: number;
  week: number;
  created_at: string;
}

export interface IncomeCode {
  code: string;
  description: string;
}

export interface Establishment {
  id: string;
  name: string;
  active: boolean;
}