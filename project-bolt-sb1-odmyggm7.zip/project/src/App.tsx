import React from 'react';
import { Building2, DollarSign, BarChart3, Plus, X } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { AuthForm } from './components/AuthForm';
import { supabase } from './lib/supabase';
import type { Cut } from './types';
import { AlertCircle } from 'lucide-react';

interface IncomeCodeType {
  code: string;
  description: string;
}

const incomeCodes: IncomeCodeType[] = [
  { code: '20000', description: 'SERVICIOS NO PERSONALES' },
  { code: '21000', description: 'SERVICIOS BASICOS' },
  { code: '21420', description: 'TELEFONIA FIJA' },
  { code: '21430', description: 'TELEFONIA CELULAR' },
  { code: '23000', description: 'MANTENIMIENTO REPARACIONES Y LIMPIEZA' },
  { code: '23100', description: 'MANTENIMIENTO Y REPARACION DE EDIFICIOS Y LOCALES' },
  { code: '23200', description: 'MANTENIMIENTO Y REPARACION DE EQUIPOS Y MEDIO DE TRANSPORTE' },
  { code: '23300', description: 'MANTENIMIENTO Y REPARACION DE EQUIPOS SANITARIOS Y LABORATORIO' },
  { code: '23360', description: 'MANTENIMIENTO Y REPARACION DE OFICINA Y MUEBLES' },
  { code: '23390', description: 'MANTENIMIENTO Y REPARACION DE OTROS EQUIPOS' },
  { code: '23400', description: 'MANTENIMIENTO Y REPARACION DE OBRAS E INSTALACIONES VARIAS' },
  { code: '23500', description: 'LIMPIEZA, ASEO Y FUMIGACION' },
  { code: '23600', description: 'MANTENIMIENTO DE SISTEMANS INFORMATICOS' },
  { code: '24000', description: 'SERVICIOS PROFESIONALES' },
  { code: '24130', description: 'SERVICIOS MEDICOS' },
  { code: '24500', description: 'SERVICIO DE CAPACITACION' },
  { code: '24900', description: 'OTROS SERVICIOS TECNICOS PROFESIONALES' },
  { code: '25000', description: 'SEVICIOS COMERCIALES Y FINANCIEROS' },
  { code: '25100', description: 'SERVICIO DE TRANSPORTE' },
  { code: '25300', description: 'SERVICIO DE IMPRENTA, PUBLICACIONES Y REPRODUCCIONES' },
  { code: '25500', description: 'COMICIONES Y GASTOS BANCARIOS' },
  { code: '25600', description: 'PUBLICIDAD Y PROPAGANDA' },
  { code: '25700', description: 'SERVICIO DE INTERNET' },
  { code: '25900', description: 'VIAJES' },
  { code: '26000', description: 'PUBLICIDAD Y PROPAGANDA' },
  { code: '26100', description: 'PASAJES NACIONALES' },
  { code: '26210', description: 'VIATICOS' },
  { code: '29000', description: 'OTROS SERVICIOS NO PERSONALES' },
  { code: '29200', description: 'SERVICIO DE VIGILANCIA' },
  { code: '31000', description: 'ALIMENTOS, PRODUCTOS AGROPECUARIOS Y FORESTALES' },
  { code: '31100', description: 'ALIMENTOS Y BEBIDAS PARA PERSONAS' },
  { code: '31500', description: 'MADERA, CORCHO Y SUS MANUFACTURAS' },
  { code: '32100', description: 'HILADOS Y TELAS' },
  { code: '32200', description: 'CONFECCIONES TEXTILES' },
  { code: '32300', description: 'PRENDAS DE VESTIR' },
  { code: '33000', description: 'PRODUCTOS DE DE PAPEL Y CARTON' },
  { code: '33100', description: 'PAPEL DE ESCRITORIO' },
  { code: '33200', description: 'PAPEL PARA COMPUTACION' },
  { code: '33300', description: 'PRODUCTOS DE ARTES GRAFICAS' },
  { code: '33400', description: 'PRODUCTOS DE PAPEL Y CARTON' },
  { code: '34100', description: 'CUEROS Y OPIELES' },
  { code: '34300', description: 'ARTICULOS DE CAUCHO' },
  { code: '34400', description: 'LLANTAS Y CAMARAS DE AIRE' },
  { code: '35100', description: 'PRODUCTOS QUIMICOS' },
  { code: '35200', description: 'PRODUCTOS FARMACEUTICOS Y MEDICINALES' },
  { code: '35210', description: 'PRODUCTOS FARMACEUTICOS Y MEDICINALES VARIOS' },
  { code: '35260', description: 'OXIGENO' },
  { code: '35265', description: 'REACTIVOS' },
  { code: '35266', description: 'OXIGENO MEDICO' },
  { code: '35270', description: 'VENDAJES PARA FRACTURAS' },
  { code: '35400', description: 'INSECTICIDAS FUGICIDAS Y OTROS' },
  { code: '35500', description: 'TINTAS PINTURAS Y COLORANTES' },
  { code: '35600', description: 'COMBUSTIBLE Y LUBRICANTES' },
  { code: '35610', description: 'GASOLINA' },
  { code: '35620', description: 'DIESEL' },
  { code: '35630', description: 'KEROSEN' },
  { code: '35640', description: 'GAS LPG' },
  { code: '35650', description: 'ACEITES Y GRASAS LUBRICANTES' },
  { code: '35800', description: 'PRODUCTOS DE MATERIAL PLASTICO' },
  { code: '35900', description: 'OTROS PRODUCTOS QUIMICOS' },
  { code: '36100', description: 'PRODUCTOS FERROSOS' },
  { code: '36300', description: 'ESTRUCTURAS METALICAS ACABADAS' },
  { code: '36400', description: 'HERRAMIENTAS MENORES' },
  { code: '36900', description: 'OTROS PRODUCTOS METALICOS' },
  { code: '36920', description: 'ACCESORIOS DE METAL' },
  { code: '36930', description: 'ELEMENTOS DE FERRETERIA' },
  { code: '37200', description: 'PRODUCTOS DE VIDRIO' },
  { code: '37300', description: 'PRODUCTOS DE LOZA Y PORCELANA' },
  { code: '37400', description: 'PRODUCTOS DE CEMENTO ASBESTO Y YESO' },
  { code: '37500', description: 'CEMENTO CAL Y YESO' },
  { code: '38400', description: 'PIEDRA, ARCILLA Y ARENA' },
  { code: '39100', description: 'ELEMENTOS DE LIMPIEZA' },
  { code: '39200', description: 'UTILES DE ESCRITORIO OFICINA Y ENCEÑANZA' },
  { code: '39300', description: 'UTILES MATERIALES ELECTRICOS' },
  { code: '39400', description: 'UTENSILIOS DE COCINA Y COMEDOR' },
  { code: '39500', description: 'INSTRUMENTAL MEDICO QUIRURGICO MENOR Y DE LABORATORIO' },
  { code: '39510', description: 'INSTRUMENTAL MEDICO QUIRURGICO MENOR' },
  { code: '39520', description: 'INSTRUMENTAL Y MATERIAL PARA LABORATORIO' },
  { code: '39530', description: 'MATERIAL MEDICO QUIRURGICO MENOR' },
  { code: '39540', description: 'OTROS INSTRUMENTAL ACCESORIOS Y MATERIAL MEDICO' },
  { code: '39550', description: 'INSTRUMENTAL ODONTOLOGICO' },
  { code: '39560', description: 'MATERIALES Y SUMINISTROS ODONTOLOGICOS' },
  { code: '39900', description: 'OTROS GASTO Y ACCESORIOS' },
  { code: '41240', description: 'INSTALACIONES VARIAS' },
  { code: '42100', description: 'EQUIPO DE MEDICINA Y MUEBLES' },
  { code: '42110', description: 'MUEBLES VARIOS DE OFICINA' },
  { code: '42120', description: 'EQUIPOS VARIOS DE OFICINA' },
  { code: '42140', description: 'ELECTRODOMESTICOS' },
  { code: '42200', description: 'MAQUINARIA Y EQUIPO DE PRODUCCION' },
  { code: '42210', description: 'EQUIPO MEDICO SANITARIO Y HOSPITALARIO E INSTRUMENTAL' },
  { code: '42420', description: 'EQUIPO DE LABORATORIO' },
  { code: '42500', description: 'EQUIPO DE COMUNICACION Y SEÑALAMIETO' },
  { code: '42600', description: 'EQUIPO PARA COMPUTACION' },
  { code: '47210', description: 'CONSTRUCCIONES Y MEJORAS' }
];

const establishments = [
  'Choloma',
  'Monterrey',
  'Lopez Arellano',
  'El Rancho',
  'La Jutosa',
  'Quebrada Seca',
  'IHSS Choloma',
  'La Bueso',
  'SMI Choloma',
  'Yami Rosental Hidalgo',
  'Omoa',
  'Cuyamelito',
  'Paraiso',
  'Jalisco',
  'Tegucigalpita',
  'Chachauala',
  'Julio Cesar Santos (Corintio)',
  'Sra. Sinia Lujan (Tulian Rios)',
  'Cuyamel',
  'Santa Teresa',
  'Coleo Alvarez Casildo',
  'German Pascua Piemienta',
  'Santiago',
  'Dr. Raul Alfredo Ugarte',
  'Suyapa',
  'Jordan',
  'Potrerillos',
  'Comello Moncada',
  'Bajamar',
  'Baracoa',
  'Caoba',
  'Kele kele',
  'La Pita',
  'Puente Alto',
  'Calan PT',
  'Saraguayna',
  'Travesia',
  'La Fraternidad',
  'Sra. Linda Coello (Medina)',
  'San Antonio (S. Barahona)',
  'Nueva Granada',
  'San Juan',
  'La Ceibita',
  'Sotero Barahona',
  'Rio Lindo',
  'San Francisco de Y.',
  'Teodoro Mancia',
  'Tacamiche',
  'La Sabana',
  'San Manuel',
  'Cowlee',
  'Guadalupe',
  'El Plan',
  'EL LLAMO (Amor Sanchez)',
  'Peña Blanca',
  'Las Flores',
  'Sta Cruz (Francisco Beltran)',
  'Yojoa',
  'San Isidro',
  'Los Caminos',
  'SMI Juan Pablo II',
  'Ing. Roberto Pineda Chacon (La Bolsita)',
  'Los Cutucos',
  'Jose Ines Rapalo (Villanueva)',
  'Dos Caminos',
  'El Milagro',
  'El Venado',
  'Nuevo Chameleon',
  'San Isidro II',
  'El Calan',
  'Sauce',
  'Nueva Suyapa',
  'SMI Villanueva',
  'Pueblo Nuevo',
  'Dr. Walter Perdomo (Col. Gracias a Dios)',
  'El Marañon',
  'El Perico',
  'Sinal',
  'Colinas de Suiza',
  'Nuestra Señora de Guadalupe',
  'La Lima',
  'Planeta',
  'Flores de Oriente'
];

interface CutRow {
  id: string;
  cutNumber: number;
  date: string;
  establishment: string;
  code: string;
  amount: number;
  month: number;
  week: number;
  codeDescription?: string;
}

const emptyRow = (): CutRow => ({
  id: crypto.randomUUID(),
  cutNumber: 0,
  date: new Date().toISOString().split('T')[0],
  establishment: '',
  code: '',
  amount: 0,
  month: new Date().getMonth() + 1,
  week: Math.ceil((new Date().getDate() + new Date(new Date().getFullYear(), new Date().getMonth(), 0).getDay()) / 7)
});

function App() {
  const [activeTab, setActiveTab] = useState<'cuts' | 'establishments' | 'reports'>('cuts');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rows, setRows] = useState<CutRow[]>(Array(20).fill(null).map(() => emptyRow()));
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthForm, setShowAuthForm] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setIsAuthenticated(!!session);
      if (session) setShowAuthForm(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const handleAddRow = () => {
    setRows(prev => [...prev, emptyRow()]);
  };

  useEffect(() => {
    if (isModalOpen) {
      setRows(Array(20).fill(null).map(() => emptyRow()));
    }
  }, [isModalOpen]);

  const handleRemoveRow = (id: string) => {
    setRows(prev => prev.filter(row => row.id !== id));
  };

  const handleRowChange = (id: string, field: keyof CutRow, value: string | number) => {
    setRows(prev => prev.map(row => {
      if (row.id === id) {
        return { ...row, [field]: value };
      }
      return row;
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      alert('Debe iniciar sesión para guardar cortes.');
      return;
    }

    // Filter out rows with empty required fields
    const validRows = rows.filter(row => 
      row.cutNumber !== 0 && 
      row.establishment !== '' && 
      row.code !== '' && 
      row.amount !== 0
    );
    
    try {
      // First, get the establishment IDs
      const { data: establishments } = await supabase
        .from('establishments')
        .select('id, name')
        .in('name', validRows.map(row => row.establishment));

      if (!establishments) {
        throw new Error('No se pudieron obtener los establecimientos');
      }

      // Create a map of establishment names to IDs
      const establishmentMap = new Map(
        establishments.map(e => [e.name, e.id])
      );

      // Prepare the cuts data
      const cutsToInsert = validRows.map(row => ({
        cut_number: row.cutNumber,
        date: row.date,
        establishment_id: establishmentMap.get(row.establishment),
        code: row.code,
        amount: row.amount,
        month: row.month,
        week: row.week
      }));

      // Insert the cuts
      const { error } = await supabase
        .from('cuts')
        .insert(cutsToInsert);

      if (error) {
        throw error;
      }

      alert('Cortes guardados exitosamente');
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error al guardar los cortes:', error);
      alert('Error al guardar los cortes. Por favor, intente nuevamente.');
    }
  };

  if (showAuthForm || !isAuthenticated) {
    return <AuthForm onSuccess={() => setShowAuthForm(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-indigo-600" />
              <h1 className="ml-2 text-xl font-semibold text-gray-900">
                Sistema de Cortes
              </h1>
            </div>
            <div>
              <button
                onClick={handleSignOut}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('cuts')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'cuts'
                  ? 'border-b-2 border-indigo-500 text-indigo-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Cortes
            </button>
            <button
              onClick={() => setActiveTab('establishments')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'establishments'
                  ? 'border-b-2 border-indigo-500 text-indigo-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Establecimientos
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'reports'
                  ? 'border-b-2 border-indigo-500 text-indigo-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Reportes
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Placeholder content - we'll implement these components next */}
        {activeTab === 'cuts' && (
          <div className="mb-6 flex justify-end">
            <button
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              onClick={() => setIsModalOpen(true)}
            >
              <Plus className="h-5 w-5 mr-2" />
              Nuevo Corte
            </button>
          </div>
        )}

        {/* Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-7xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center px-6 py-4 border-b">
                <h2 className="text-lg font-semibold text-gray-900">Nuevo Corte</h2>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <form onSubmit={handleSubmit} className="p-6">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Fecha
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Corte
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Establecimiento
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Código
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Monto
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Mes
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Semana
                        </th>
                        <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Acciones
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {rows.map((row) => (
                        <tr key={row.id}>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="date"
                              value={row.date}
                              onChange={(e) => handleRowChange(row.id, 'date', e.target.value)}
                              className="block w-full px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                            />
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="number"
                              value={row.cutNumber}
                              onChange={(e) => handleRowChange(row.id, 'cutNumber', parseInt(e.target.value) || 0)}
                              className="block w-20 px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                            />
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <select
                              value={row.establishment}
                              onChange={(e) => handleRowChange(row.id, 'establishment', e.target.value)}
                              className="block w-full px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                            >
                              <option value="">Seleccionar</option>
                              {establishments.map((establishment) => (
                                <option key={establishment} value={establishment}>
                                  {establishment}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="text"
                              list="income-codes"
                              value={row.code}
                              onChange={(e) => handleRowChange(row.id, 'code', e.target.value)}
                              className="block w-full px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                              placeholder="Escriba o seleccione un código"
                            />
                            <datalist id="income-codes">
                              {incomeCodes.map(code => (
                                <option key={code.code} value={code.code} />
                              ))}
                            </datalist>
                            {row.code && (
                              <div className="mt-1 text-xs text-gray-500">
                                {incomeCodes.find(c => c.code === row.code)?.description}
                              </div>
                            )}
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="number"
                              value={row.amount}
                              onChange={(e) => handleRowChange(row.id, 'amount', parseFloat(e.target.value) || 0)}
                              className="block w-32 px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                              min="0"
                              step="0.01"
                            />
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="number"
                              value={row.month}
                              onChange={(e) => handleRowChange(row.id, 'month', parseInt(e.target.value) || 1)}
                              className="block w-20 px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                              min="1"
                              max="12"
                            />
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <input
                              type="number"
                              value={row.week}
                              onChange={(e) => handleRowChange(row.id, 'week', parseInt(e.target.value) || 1)}
                              className="block w-20 px-2 py-1 text-sm border rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                              min="1"
                              max="53"
                            />
                          </td>
                          <td className="px-2 py-2 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleRemoveRow(row.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-6 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={handleAddRow}
                    className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Agregar Fila
                  </button>
                  
                  <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    title="Se guardarán solo las filas con Corte, Establecimiento, Código y Monto completos"
                  >
                    Guardar
                  </button>
                </div>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow p-6">
          {activeTab === 'cuts' && (
            <div className="text-center py-12">
              <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-semibold text-gray-900">Sin cortes registrados</h3>
              <p className="mt-1 text-sm text-gray-500">
                Comienza agregando un nuevo corte.
              </p>
            </div>
          )}
          {activeTab === 'establishments' && (
            <div className="text-center py-12">
              <Building2 className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-semibold text-gray-900">Sin establecimientos</h3>
              <p className="mt-1 text-sm text-gray-500">
                Agrega los establecimientos para comenzar.
              </p>
            </div>
          )}
          {activeTab === 'reports' && (
            <div className="text-center py-12">
              <BarChart3 className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-semibold text-gray-900">Reportes</h3>
              <p className="mt-1 text-sm text-gray-500">
                Visualiza los reportes por establecimiento, código o período.
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App